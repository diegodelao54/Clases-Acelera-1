package com.springwebflux.flux;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FluxApplicationTests {

	@Test
	void contextLoads() {
	}

}
