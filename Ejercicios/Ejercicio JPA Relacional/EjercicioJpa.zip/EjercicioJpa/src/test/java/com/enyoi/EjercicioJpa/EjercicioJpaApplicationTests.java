package com.enyoi.EjercicioJpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
